mdEditor source 1.0.14 promotional material, 2026-10-20.
Guide: https://5garashi.github.io/mdEditor/
English: https://5garashi.github.io/mdEditor/en.html
Created by 5garashi.com Design Office. Material and code: MIT. Official logos: CC BY-ND 4.0.
Design reference: Design Office Identity 4.20.0, checked 2026-10-20.
Samples target mdEditor; not every notation renders on GitHub.
See THIRD-PARTY-NOTICES.md for credits.
